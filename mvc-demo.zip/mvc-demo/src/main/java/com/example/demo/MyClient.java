package com.example.demo;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.demo.model.Product;

@FeignClient(value = "myclient-api", url = "http://localhost:5000")
public interface MyClient {

	@PostMapping("/product")
	public Product addProduct(@RequestBody Product product);
	@GetMapping("/product")
	public List<Product> getAllProducts();
	@GetMapping("/product/{id}")
	public Product findProductById(@PathVariable("id") Long id);
	@PutMapping("/product")
	public Product modifyProduct(@RequestBody Product product);
	@DeleteMapping("/product/{id}")
	public void removeProduct(@PathVariable("id") Long id);
	
}
