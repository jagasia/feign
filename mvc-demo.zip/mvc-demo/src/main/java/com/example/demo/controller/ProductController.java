package com.example.demo.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.MyClient;
import com.example.demo.model.Product;

@Controller
public class ProductController {
	@Autowired
	private MyClient mc;
	
	@GetMapping("/")
	public ModelAndView home()
	{
		List<Product> products = mc.getAllProducts();
		ModelAndView mv=new ModelAndView();
		mv.setViewName("product");
		mv.addObject("products",products);
		mv.addObject("product",new Product());
		return mv;
	}
	
	@GetMapping("/select/{id}")
	public ModelAndView select(@PathVariable("id") Long id)
	{
		Product product = mc.findProductById(id);
		List<Product> products = mc.getAllProducts();
		ModelAndView mv=new ModelAndView();
		mv.setViewName("product");
		mv.addObject("products",products);
		mv.addObject("product",product);
		return mv;
	}
	
	@RequestMapping(method =RequestMethod.POST, value = "/product", params = "add")
	public ModelAndView addProduct(@ModelAttribute("product") Product product)
	{
		Product result = mc.addProduct(product);
		return home();
	}
	
	@RequestMapping(method =RequestMethod.POST, value = "/product", params = "modify")
	public ModelAndView modifyProduct(@ModelAttribute("product") Product product)
	{
		Product result = mc.modifyProduct(product);
		return home();
	}
	
	@RequestMapping(method =RequestMethod.POST, value = "/product", params = "delete")
	public ModelAndView deleteProduct(@ModelAttribute("product") Product product, HttpSession session)
	{
		mc.removeProduct(product.getId());
		return home();
	}
}
